package com.example.radiobox;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends Activity implements View.OnClickListener {
    CheckBox chkSugar;
    CheckBox chkCream;
    RadioGroup radCoffeeType;
    RadioButton radDecaf;
    RadioButton radExpresso;
    RadioButton radColombian;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout);

        chkCream = (CheckBox)findViewById(R.id.chkCream);
        chkSugar = (CheckBox)findViewById(R.id.chkSugar);
        radCoffeeType = (RadioGroup)findViewById(R.id.radCoffeeType);
        radDecaf = (RadioButton)findViewById(R.id.radDecaf);
        radExpresso = (RadioButton)findViewById(R.id.radExpresso);
        radColombian = (RadioButton)findViewById(R.id.radColombian);
    }

    @Override
    public void onClick(View view) {
        String message = "Coffee";
        if (chkCream.isChecked())
            message += " & Cream";
        if (chkSugar.isChecked())
            message += " & Sugar";

        int radioId = radCoffeeType.getCheckedRadioButtonId();
        if (radColombian.getId() == radioId)
            message = "Colombian " + message;
        if (radExpresso.isChecked())
            message = "Expresso " + message;
        if (radDecaf.isChecked())
            message = "Decaf " + message;

        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
    }
}
