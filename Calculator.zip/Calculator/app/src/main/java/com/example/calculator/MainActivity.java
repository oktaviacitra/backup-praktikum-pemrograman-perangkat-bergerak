package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText editText;
    String display = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bundle);

        editText = (EditText) findViewById(R.id.editText);
    }

    public void onClickButton(View v) {
        display += ((Button) v).getText();
        display = display.replaceAll(",", "");

        int commaTotal = display.length() / 3;
        int commaIndex = display.length() % 3;

        for (int i = 0; i < commaTotal; i++) {
            if (commaIndex != 0) {
                display = insertComma(display, commaIndex);
                commaIndex += 4;
            } else
                commaIndex += 3;
        }
        editText.setText(display);
    }

    public String insertComma(String str, int index) {
        String result = str.substring(0, index) + "," + str.substring(index);
        return result;
    }
}
