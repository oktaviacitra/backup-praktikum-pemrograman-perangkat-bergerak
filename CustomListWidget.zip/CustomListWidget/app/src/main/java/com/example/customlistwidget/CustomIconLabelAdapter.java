package com.example.customlistwidget;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

class CustomIconLabelAdapter extends ArrayAdapter<String> {
    Context context;
    Integer[] thumbnails;
    String[] items;
    String[] infos;
    public CustomIconLabelAdapter(Context context, int layoutToBeInflated, String[] items, Integer[] thumbnails, String[] infos) {
        super(context, R.layout.custom_row_icon_label, items);
        this.context = context;
        this.thumbnails = thumbnails;
        this.items = items;
        this.infos = infos;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = ((Activity) context).getLayoutInflater();
        View row = inflater.inflate(R.layout.custom_row_icon_label, null);
        TextView title = (TextView) row.findViewById(R.id.title);
        ImageView icon = (ImageView) row.findViewById(R.id.icon);
        TextView info = (TextView) row.findViewById(R.id.info);
        title.setText(items[position]);
        icon.setImageResource(thumbnails[position]);
        info.setText(infos[position]);
        return row;
    }
}
