package com.example.customlistwidget;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends ListActivity {
    TextView txtMsg;
    String[] items = {"Data-1", "Data-2", "Data-3", "Data-4", "Data-5", "Data-6", "Data-7", "Data-8"};
    String[] infos = {"ice bear-1", "ice bear-2", "ice bear-3", "ice bear-4", "ice bear-5", "ice bear-6", "ice bear-7", "ice bear-8"};
    Integer[] thumbnails = {R.drawable.a, R.drawable.b, R.drawable.c, R.drawable.d, R.drawable.e, R.drawable.f, R.drawable.g, R.drawable.h};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);
        txtMsg = (TextView) findViewById(R.id.txtMsg);
        CustomIconLabelAdapter adapter = new CustomIconLabelAdapter(this, R.layout.custom_row_icon_label, items, thumbnails, infos);
        setListAdapter(adapter);
    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);
        String text = " Position: " + position + " " + items[position] + " " + infos[position];
        txtMsg.setText(text);
        Toast.makeText(getApplicationContext(), text, Toast.LENGTH_SHORT).show();
    }
}
