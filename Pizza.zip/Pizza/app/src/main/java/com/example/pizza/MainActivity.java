package com.example.pizza;

import androidx.appcompat.app.AppCompatActivity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    RadioGroup radPizzaType;
    RadioButton radTunaMelt;
    RadioButton radMeatLovers;
    RadioButton radShrimpCrispy;
    CheckBox chkMozarella;
    CheckBox chkSausage;
    CheckBox chkSpicy;
    CheckBox chkSoftDrink;
    CheckBox chkMilkshake;
    CheckBox chkFrappucino;
    CheckBox chkFrenchFries;
    CheckBox chkChickenWings;
    CheckBox chkRollade;
    Button btnTotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout);

        radPizzaType = (RadioGroup)findViewById(R.id.radPizzaType);
        radTunaMelt = (RadioButton)findViewById(R.id.radTunaMelt);
        radMeatLovers = (RadioButton)findViewById(R.id.radMeatLovers);
        radShrimpCrispy = (RadioButton)findViewById(R.id.radShrimpCrispy);
        chkMozarella = (CheckBox)findViewById(R.id.chkMozarella);
        chkSausage = (CheckBox)findViewById(R.id.chkSausage);
        chkSpicy = (CheckBox)findViewById(R.id.chkSpicy);
        chkSoftDrink = (CheckBox)findViewById(R.id.chkSoftDrink);
        chkMilkshake = (CheckBox)findViewById(R.id.chkMilkshake);
        chkFrappucino = (CheckBox)findViewById(R.id.chkFrappucino);
        chkFrenchFries = (CheckBox)findViewById(R.id.chkFrenchFries);
        chkChickenWings = (CheckBox)findViewById(R.id.chkChickenWings);
        chkRollade = (CheckBox)findViewById(R.id.chkRollade);
        btnTotal = (Button)findViewById(R.id.btnTotal);
        btnTotal.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        String nota = "", pizza = "Pizza: ", topping="\nTopping: ", beverage="\nBeverage: ",
                snack="\nSnack:";
        int total = 0;

        int radioId = radPizzaType.getCheckedRadioButtonId();
        if (radTunaMelt.getId() == radioId) {
            pizza += "Tuna Melt";
            total += 35000;
        }
        if (radMeatLovers.isChecked()) {
            pizza += "Meat Lovers";
            total += 40000;
        }
        if (radShrimpCrispy.isChecked()) {
            pizza += "Shrimp Crispy";
            total += 35000;
        }

        if (chkMozarella.isChecked()) {
            topping += "Mozarella";
            total += 20000;
        }
        if (chkSausage.isChecked()) {
            topping += "Sausage";
            total += 15000;
        }
        if (chkSpicy.isChecked()) {
            topping += "Spicy";
            total += 5000;
        }
        if (chkSoftDrink.isChecked()) {
            beverage += "Soft Drink";
            total += 10000;
        }
        if (chkMilkshake.isChecked()) {
            beverage += "Milkshake";
            total += 25000;
        }
        if (chkFrappucino.isChecked()) {
            beverage += "Frappucino";
            total += 25000;
        }
        if (chkFrenchFries.isChecked()) {
            snack += "French Fries";
            total += 20000;
        }
        if (chkChickenWings.isChecked()) {
            snack += "Chicken Wings";
            total += 35000;
        }
        if (chkRollade.isChecked()) {
            snack += "Rollade";
            total += 25000;
        }
        nota = pizza + topping + beverage + snack +"Total: Rp." + total + ",-";
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setMessage(nota);
        builder.setTitle("NOTA");
        builder.setCancelable(false);
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {

                finish();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                dialog.cancel();
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
}
