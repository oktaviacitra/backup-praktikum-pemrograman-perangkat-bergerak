package com.example.checkbox;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

public class MainActivity extends Activity implements View.OnClickListener {
    CheckBox chkCream;
    CheckBox chkSugar;
    Button btnPay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout);
        chkCream = (CheckBox) findViewById(R.id.chkCream);
        chkSugar = (CheckBox) findViewById(R.id.chkSugar);
        btnPay = (Button) findViewById(R.id.btnPay);
        btnPay.setOnClickListener(this);
    }


    @Override
    public void onClick(View view) {
        String message = "Coffee";
        if (chkCream.isChecked())
            message += " & Cream";
        if (chkSugar.isChecked())
            message += " & Sugar";
        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
    }
}
